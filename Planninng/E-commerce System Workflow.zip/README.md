
  # E-commerce System Workflow

  This is a code bundle for E-commerce System Workflow. The original project is available at https://www.figma.com/design/TQjn2IlgR0HdjgCgqL9sj2/E-commerce-System-Workflow.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  