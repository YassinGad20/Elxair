import { useState } from "react";
import {
  ShoppingCart, X, Star, Plus, Minus, Package, Users, TrendingUp,
  ShoppingBag, BarChart2, ChevronRight, Sparkles, Bot, Search,
  Eye, Pencil, Trash2, CheckCircle, ArrowRight, LogIn, Lock, AlertCircle,
} from "lucide-react";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  AreaChart, Area,
} from "recharts";

// ─── Types ────────────────────────────────────────────────────────────────────

type Category = "الكل" | "عود" | "زهري" | "مسك" | "شرقي" | "غربي";
type View = "home" | "product" | "cart" | "checkout" | "admin";
type AdminTab = "overview" | "products" | "orders";
type OrderStatus = "جديد" | "قيد التجهيز" | "مكتمل" | "ملغي";

interface Perfume {
  id: number;
  name: string;
  brand: string;
  category: string;
  price: number;
  sizes: number[];
  rating: number;
  reviews: number;
  image: string;
  description: string;
  notes: { top: string[]; heart: string[]; base: string[] };
  stock: number;
}

interface CartItem {
  perfume: Perfume;
  size: number;
  qty: number;
}

interface Order {
  id: string;
  customer: string;
  date: string;
  total: number;
  status: OrderStatus;
  items: number;
}

// ─── Data ─────────────────────────────────────────────────────────────────────

const PERFUMES: Perfume[] = [
  {
    id: 1, name: "عود الملكي", brand: "دار الفخامة", category: "عود",
    price: 850, sizes: [30, 50, 100], rating: 4.9, reviews: 247, stock: 45,
    image: "1774682060997-f8959850a7d4",
    description: "عطر ملكي فاخر مستوحى من خشب العود الأصيل، يمزج بين عمق الشرق وأناقة العصر الحديث في تركيبة تدوم طويلاً.",
    notes: { top: ["العود", "الورد الطائفي"], heart: ["المسك", "الياسمين"], base: ["الأنبر", "الصندل"] },
  },
  {
    id: 2, name: "ورد الطائف", brand: "بيت الريحان", category: "زهري",
    price: 620, sizes: [50, 100], rating: 4.7, reviews: 183, stock: 32,
    image: "1737920459846-2d0318700658",
    description: "رحلة عطرية إلى قلب وردة الطائف النادرة، تنساب برقة على الجلد وتترك أثراً عطرياً رائعاً طوال اليوم.",
    notes: { top: ["الورد", "الفاوانيا"], heart: ["العنبر", "الياسمين"], base: ["المسك", "الخشب الأبيض"] },
  },
  {
    id: 3, name: "مسك السحاب", brand: "نسمة للعطور", category: "مسك",
    price: 480, sizes: [30, 50, 100], rating: 4.6, reviews: 312, stock: 78,
    image: "1780943004195-3bd30f748872",
    description: "نقاء المسك الأبيض مع لمسات خفيفة من البودر الناعم، خيار مثالي لمن يعشقون العطور الهادئة والمميزة.",
    notes: { top: ["البرغموت", "الليمون النضر"], heart: ["المسك الأبيض"], base: ["البودر", "الفانيليا الدافئة"] },
  },
  {
    id: 4, name: "ليالي الشرق", brand: "دار الفخامة", category: "شرقي",
    price: 730, sizes: [50, 100], rating: 4.8, reviews: 156, stock: 19,
    image: "1774682060992-46c7e9f2e50b",
    description: "تجسيد لروح الليالي الشرقية الفاخرة، تركيبة تأسر القلوب وتبقى في الذاكرة طويلاً.",
    notes: { top: ["التوابل الشرقية", "الزعفران"], heart: ["العود", "الورد البلغاري"], base: ["الأنبر الرمادي", "المسك الأسود"] },
  },
  {
    id: 5, name: "نسيم باريس", brand: "مون بليو", category: "غربي",
    price: 560, sizes: [30, 50, 100], rating: 4.5, reviews: 98, stock: 54,
    image: "1771762013405-ad64577dfc55",
    description: "إلهام فرنسي بلمسة عربية أصيلة، يجمع بين أناقة الغرب وعمق الشرق في تناغم نادر ومتفرد.",
    notes: { top: ["الهيسوب", "البرتقال المر"], heart: ["الورد الفرنسي", "الأيريس"], base: ["خشب الأرز", "المسك الأبيض"] },
  },
  {
    id: 6, name: "دخان الغابة", brand: "بيت الريحان", category: "عود",
    price: 920, sizes: [50, 100], rating: 4.9, reviews: 89, stock: 12,
    image: "1778058505479-447c46d800a0",
    description: "قوة العود البرية تلتقي مع الدخان العتيق في تركيبة جريئة لمن يعشقون العطور العميقة والاستثنائية.",
    notes: { top: ["الدخان", "الفلفل الأسود"], heart: ["العود الهندي الخام"], base: ["اللادنم", "الفتكور الأرضي"] },
  },
  {
    id: 7, name: "أمواج المطر", brand: "نسمة للعطور", category: "زهري",
    price: 390, sizes: [30, 50, 100], rating: 4.4, reviews: 207, stock: 63,
    image: "1738414808975-201966230c59",
    description: "انتعاش المطر الأول على الأزهار البرية، خفيف وعفوي ومليء بالحيوية والبهجة.",
    notes: { top: ["رائحة المطر", "الخضرة الطازجة"], heart: ["الياسمين البري", "التفاح"], base: ["المسك المائي الخفيف"] },
  },
  {
    id: 8, name: "أسرار القصر", brand: "دار الفخامة", category: "شرقي",
    price: 1100, sizes: [50, 100], rating: 5.0, reviews: 34, stock: 7,
    image: "1739190940453-20900e9d18fb",
    description: "قمة الترف والرقي، تركيبة حصرية مصنوعة من أثمن مكونات العطور في العالم، تجربة لا تُنسى.",
    notes: { top: ["الزعفران الإيراني الخالص", "الهيل"], heart: ["العود الكمبودي", "الورد البلغاري الخام"], base: ["الأنبر الرمادي", "المسك الأبيض النقي"] },
  },
];

const ORDERS: Order[] = [
  { id: "ORD-2401", customer: "محمد الشمري", date: "2024-01-15", total: 1470, status: "مكتمل", items: 2 },
  { id: "ORD-2402", customer: "نورة العتيبي", date: "2024-01-16", total: 850, status: "قيد التجهيز", items: 1 },
  { id: "ORD-2403", customer: "فهد القحطاني", date: "2024-01-17", total: 2150, status: "جديد", items: 3 },
  { id: "ORD-2404", customer: "سارة المطيري", date: "2024-01-17", total: 620, status: "جديد", items: 1 },
  { id: "ORD-2405", customer: "عبدالله الدوسري", date: "2024-01-14", total: 480, status: "ملغي", items: 1 },
  { id: "ORD-2406", customer: "ريم الزهراني", date: "2024-01-13", total: 1840, status: "مكتمل", items: 2 },
  { id: "ORD-2407", customer: "خالد البقمي", date: "2024-01-12", total: 3200, status: "مكتمل", items: 4 },
];

const SALES_DATA = [
  { month: "يوليو", sales: 42000, orders: 68, profit: 18500 },
  { month: "أغسطس", sales: 51000, orders: 82, profit: 22000 },
  { month: "سبتمبر", sales: 47000, orders: 74, profit: 20100 },
  { month: "أكتوبر", sales: 63000, orders: 101, profit: 27500 },
  { month: "نوفمبر", sales: 78000, orders: 124, profit: 34200 },
  { month: "ديسمبر", sales: 95000, orders: 152, profit: 41800 },
  { month: "يناير", sales: 61000, orders: 97, profit: 26700 },
];

const ML_PREDICTIONS = [
  { category: "عود", current: 41800, predicted: 58200, growth: 39 },
  { category: "شرقي", current: 33500, predicted: 44700, growth: 33 },
  { category: "زهري", current: 28400, predicted: 35100, growth: 24 },
  { category: "غربي", current: 15200, predicted: 17900, growth: 18 },
  { category: "مسك", current: 19600, predicted: 22800, growth: 16 },
];

const CATEGORIES: Category[] = ["الكل", "عود", "زهري", "مسك", "شرقي", "غربي"];

const perfumePrice = (p: Perfume, size: number) =>
  size === 30 ? p.price : size === 50 ? Math.round(p.price * 1.6) : Math.round(p.price * 2.8);

const img = (id: string, w = 600, h = 750) =>
  `https://images.unsplash.com/photo-${id}?w=${w}&h=${h}&fit=crop&auto=format`;

// ─── Utility Components ───────────────────────────────────────────────────────

function GoldDivider() {
  return (
    <div className="flex items-center gap-3 my-2">
      <div className="flex-1 h-px bg-gradient-to-l from-transparent via-primary/50 to-primary/70" />
      <div className="w-1 h-1 rotate-45 bg-primary/60" />
      <div className="flex-1 h-px bg-gradient-to-r from-transparent via-primary/50 to-primary/70" />
    </div>
  );
}

function Stars({ rating, size = 12 }: { rating: number; size?: number }) {
  return (
    <div className="flex gap-0.5">
      {[1, 2, 3, 4, 5].map((i) => (
        <Star
          key={i}
          size={size}
          className={i <= Math.round(rating) ? "fill-primary text-primary" : "text-muted-foreground/25"}
        />
      ))}
    </div>
  );
}

function StatusBadge({ status }: { status: OrderStatus }) {
  const styles: Record<OrderStatus, string> = {
    جديد: "bg-blue-500/10 text-blue-400 border border-blue-500/25",
    "قيد التجهيز": "bg-amber-500/10 text-amber-400 border border-amber-500/25",
    مكتمل: "bg-emerald-500/10 text-emerald-400 border border-emerald-500/25",
    ملغي: "bg-red-500/10 text-red-400 border border-red-500/25",
  };
  return (
    <span className={`text-[11px] px-2 py-0.5 font-medium ${styles[status]}`}>
      {status}
    </span>
  );
}

// ─── Admin Login ──────────────────────────────────────────────────────────────

const ADMIN_CREDENTIALS = { username: "admin", password: "utoor2024" };

function AdminLogin({
  onSuccess,
  onCancel,
}: {
  onSuccess: () => void;
  onCancel: () => void;
}) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(false);
    setTimeout(() => {
      if (
        username === ADMIN_CREDENTIALS.username &&
        password === ADMIN_CREDENTIALS.password
      ) {
        onSuccess();
      } else {
        setError(true);
        setLoading(false);
      }
    }, 600);
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-background/90 backdrop-blur-sm">
      <div className="relative w-full max-w-sm mx-4">
        {/* Decorative top line */}
        <div className="h-px bg-gradient-to-r from-transparent via-primary to-transparent mb-px" />

        <div className="bg-card border border-border p-8">
          <button
            onClick={onCancel}
            className="absolute top-4 left-4 text-muted-foreground hover:text-foreground transition-colors"
          >
            <X size={16} />
          </button>

          <div className="text-center mb-8">
            <div className="w-12 h-12 border border-primary/40 bg-primary/5 flex items-center justify-center mx-auto mb-4">
              <Lock size={18} className="text-primary" />
            </div>
            <p
              className="text-primary text-xs tracking-[0.3em] uppercase mb-1"
              style={{ fontFamily: "Cinzel, serif" }}
            >
              Admin Access
            </p>
            <h2 className="text-lg font-bold text-foreground">تسجيل دخول الإدارة</h2>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-[11px] text-muted-foreground tracking-widest uppercase mb-1.5">
                اسم المستخدم
              </label>
              <input
                required
                autoFocus
                value={username}
                onChange={(e) => { setUsername(e.target.value); setError(false); }}
                className={`w-full px-3 py-2.5 bg-background border text-foreground text-sm focus:outline-none transition-colors ${error ? "border-destructive/60" : "border-border focus:border-primary/50"}`}
              />
            </div>
            <div>
              <label className="block text-[11px] text-muted-foreground tracking-widest uppercase mb-1.5">
                كلمة المرور
              </label>
              <input
                required
                type="password"
                value={password}
                onChange={(e) => { setPassword(e.target.value); setError(false); }}
                className={`w-full px-3 py-2.5 bg-background border text-foreground text-sm focus:outline-none transition-colors ${error ? "border-destructive/60" : "border-border focus:border-primary/50"}`}
              />
            </div>

            {error && (
              <div className="flex items-center gap-2 text-destructive text-xs bg-destructive/8 border border-destructive/20 px-3 py-2">
                <AlertCircle size={13} />
                اسم المستخدم أو كلمة المرور غير صحيحة
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 bg-primary text-primary-foreground text-sm font-medium tracking-widest hover:bg-primary/90 transition-colors disabled:opacity-60 flex items-center justify-center gap-2"
            >
              {loading ? (
                <span className="inline-block w-4 h-4 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" />
              ) : (
                <>
                  <LogIn size={14} />
                  دخول
                </>
              )}
            </button>
          </form>

          <p className="text-center text-[11px] text-muted-foreground/50 mt-6">
            للتجربة: admin / utoor2024
          </p>
        </div>

        <div className="h-px bg-gradient-to-r from-transparent via-primary to-transparent mt-px" />
      </div>
    </div>
  );
}

// ─── Navbar ───────────────────────────────────────────────────────────────────

function Navbar({
  view,
  onNav,
  cartCount,
  isAdmin,
  onAdminClick,
  onAdminLogout,
}: {
  view: View;
  onNav: (v: View) => void;
  cartCount: number;
  isAdmin: boolean;
  onAdminClick: () => void;
  onAdminLogout: () => void;
}) {
  return (
    <header className="fixed top-0 inset-x-0 z-50 border-b border-border/60 bg-background/95 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
        <button
          onClick={() => onNav("home")}
          className="text-2xl tracking-[0.25em] text-primary"
          style={{ fontFamily: "Cinzel, serif", fontWeight: 600 }}
        >
          ÛTOOR
        </button>

        <nav className="hidden md:flex items-center gap-8">
          {(
            [
              ["home", "الرئيسية"],
              ["product", "المنتجات"],
            ] as const
          ).map(([v, label]) => (
            <button
              key={v}
              onClick={() => onNav(v)}
              className={`text-sm transition-colors ${
                view === v
                  ? "text-primary"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              {label}
            </button>
          ))}
        </nav>

        <div className="flex items-center gap-3">
          <button
            onClick={() => onNav("cart")}
            className="relative p-2 text-muted-foreground hover:text-primary transition-colors"
          >
            <ShoppingCart size={20} />
            {cartCount > 0 && (
              <span className="absolute -top-0.5 -left-0.5 w-4 h-4 rounded-full bg-primary text-primary-foreground text-[10px] flex items-center justify-center font-bold leading-none">
                {cartCount}
              </span>
            )}
          </button>
          {isAdmin ? (
            <div className="flex items-center gap-2">
              <button
                onClick={() => onNav("admin")}
                className="text-xs px-3 py-1.5 border border-primary/40 bg-primary/8 text-primary hover:bg-primary/15 transition-all"
              >
                لوحة التحكم
              </button>
              <button
                onClick={onAdminLogout}
                title="تسجيل الخروج"
                className="p-1.5 text-muted-foreground hover:text-destructive transition-colors"
              >
                <ArrowRight size={16} />
              </button>
            </div>
          ) : (
            <button
              onClick={onAdminClick}
              className="text-xs px-3 py-1.5 border border-border hover:border-primary/50 text-muted-foreground hover:text-primary transition-all flex items-center gap-1.5"
            >
              <Lock size={11} />
              لوحة التحكم
            </button>
          )}
        </div>
      </div>
    </header>
  );
}

// ─── Home View ────────────────────────────────────────────────────────────────

function HomeView({
  onSelectProduct,
  onAddToCart,
}: {
  onSelectProduct: (p: Perfume) => void;
  onAddToCart: (p: Perfume, size: number) => void;
}) {
  const [activeCategory, setActiveCategory] = useState<Category>("الكل");
  const [search, setSearch] = useState("");

  const filtered = PERFUMES.filter((p) => {
    const matchCat = activeCategory === "الكل" || p.category === activeCategory;
    const matchSearch = p.name.includes(search) || p.brand.includes(search);
    return matchCat && matchSearch;
  });

  return (
    <div className="pt-16">
      {/* Hero */}
      <section className="relative h-[72vh] min-h-[520px] flex items-center overflow-hidden">
        <div className="absolute inset-0 bg-card">
          <img
            src={img("1771762013405-ad64577dfc55", 1800, 1000)}
            alt="عطر فاخر"
            className="w-full h-full object-cover opacity-35"
          />
          <div className="absolute inset-0 bg-gradient-to-l from-background/95 via-background/60 to-background/10" />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent" />
        </div>

        {/* Decorative lines */}
        <div className="absolute left-0 top-0 bottom-0 w-px bg-gradient-to-b from-transparent via-primary/20 to-transparent" />

        <div className="relative max-w-7xl mx-auto px-6 w-full">
          <div className="max-w-lg">
            <p
              className="text-primary text-xs tracking-[0.35em] uppercase mb-5"
              style={{ fontFamily: "Cinzel, serif" }}
            >
              Collection 2024
            </p>
            <h1 className="text-5xl md:text-6xl font-bold leading-tight mb-6 text-foreground">
              اكتشف عالم
              <br />
              <span className="text-primary">العطور الفاخرة</span>
            </h1>
            <p className="text-muted-foreground text-base mb-10 leading-relaxed">
              مجموعة مختارة من أرقى العطور الشرقية والغربية، تروي قصة الفخامة
              والأصالة عبر الأجيال
            </p>
            <div className="flex items-center gap-4">
              <button
                onClick={() =>
                  document
                    .getElementById("products")
                    ?.scrollIntoView({ behavior: "smooth" })
                }
                className="px-8 py-3.5 bg-primary text-primary-foreground text-sm font-medium tracking-wide hover:bg-primary/90 transition-colors"
              >
                تسوق الآن
              </button>
              <button className="text-sm text-muted-foreground hover:text-foreground transition-colors flex items-center gap-2">
                <span>اكتشف المجموعة</span>
                <ChevronRight size={14} />
              </button>
            </div>
          </div>
        </div>

        {/* Stats strip */}
        <div className="absolute bottom-0 inset-x-0 border-t border-border/40 bg-background/80 backdrop-blur-sm">
          <div className="max-w-7xl mx-auto px-6 py-4 flex items-center gap-10">
            {[
              ["٨٠+", "عطر فاخر"],
              ["١٢٠٠+", "عميل راضٍ"],
              ["٤", "دور عطور مميزة"],
              ["شحن مجاني", "فوق ٥٠٠ ر.س"],
            ].map(([num, label]) => (
              <div key={label} className="text-center">
                <p className="text-primary font-bold text-lg leading-none">{num}</p>
                <p className="text-muted-foreground text-xs mt-1">{label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Products Section */}
      <section id="products" className="max-w-7xl mx-auto px-6 py-14">
        {/* Filters */}
        <div className="flex flex-col md:flex-row gap-4 items-start md:items-center justify-between mb-10">
          <div className="flex flex-wrap gap-2">
            {CATEGORIES.map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-4 py-1.5 text-sm border transition-all duration-200 ${
                  activeCategory === cat
                    ? "border-primary bg-primary/10 text-primary"
                    : "border-border text-muted-foreground hover:border-primary/35 hover:text-foreground"
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
          <div className="relative">
            <Search
              size={14}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground"
            />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="ابحث عن عطر..."
              className="pl-4 pr-9 py-2 text-sm bg-card border border-border text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:border-primary/40 w-56"
            />
          </div>
        </div>

        {/* Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5">
          {filtered.map((perfume) => (
            <div
              key={perfume.id}
              className="group cursor-pointer"
              onClick={() => onSelectProduct(perfume)}
            >
              <div className="relative overflow-hidden bg-card aspect-[3/4] mb-3">
                <img
                  src={img(perfume.image, 400, 530)}
                  alt={perfume.name}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-background/90 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-4">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onAddToCart(perfume, perfume.sizes[0]);
                    }}
                    className="w-full py-2.5 bg-primary text-primary-foreground text-sm text-center hover:bg-primary/90 transition-colors font-medium"
                  >
                    أضف إلى السلة
                  </button>
                </div>
                {perfume.stock < 15 && (
                  <div className="absolute top-3 right-3 bg-red-600/90 text-white text-[10px] px-2 py-0.5 backdrop-blur-sm">
                    كمية محدودة
                  </div>
                )}
              </div>
              <div>
                <p className="text-[10px] text-muted-foreground tracking-widest mb-1 uppercase">
                  {perfume.brand}
                </p>
                <h3 className="text-foreground font-medium mb-1.5">{perfume.name}</h3>
                <div className="flex items-center justify-between">
                  <Stars rating={perfume.rating} />
                  <span className="text-primary font-semibold text-sm">
                    {perfume.price} ر.س
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {filtered.length === 0 && (
          <div className="text-center py-20 text-muted-foreground">
            لا توجد منتجات مطابقة للبحث
          </div>
        )}
      </section>
    </div>
  );
}

// ─── Product View ─────────────────────────────────────────────────────────────

function ProductView({
  perfume,
  onBack,
  onAddToCart,
}: {
  perfume: Perfume;
  onBack: () => void;
  onAddToCart: (p: Perfume, size: number, qty: number) => void;
}) {
  const [selectedSize, setSelectedSize] = useState(perfume.sizes[0]);
  const [qty, setQty] = useState(1);

  const recommended = PERFUMES.filter(
    (p) => p.category === perfume.category && p.id !== perfume.id
  ).slice(0, 3);

  const totalPrice = perfumePrice(perfume, selectedSize) * qty;

  return (
    <div className="pt-16 min-h-screen">
      <div className="max-w-7xl mx-auto px-6 py-12">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-sm text-muted-foreground hover:text-primary transition-colors mb-12"
        >
          <ChevronRight size={16} />
          العودة للمنتجات
        </button>

        <div className="grid md:grid-cols-2 gap-16 items-start">
          {/* Image */}
          <div className="md:sticky md:top-24">
            <div className="bg-card aspect-[3/4] overflow-hidden">
              <img
                src={img(perfume.image, 900, 1200)}
                alt={perfume.name}
                className="w-full h-full object-cover"
              />
            </div>
            <div className="flex gap-2 mt-3">
              {[perfume.image, PERFUMES[(perfume.id % 4) + 1]?.image].filter(Boolean).map(
                (imgId, i) => (
                  <div key={i} className={`w-16 h-20 bg-card overflow-hidden cursor-pointer border ${i === 0 ? "border-primary" : "border-border/50"}`}>
                    <img
                      src={img(imgId, 120, 160)}
                      alt=""
                      className="w-full h-full object-cover"
                    />
                  </div>
                )
              )}
            </div>
          </div>

          {/* Details */}
          <div className="py-2">
            <p
              className="text-primary text-[11px] tracking-[0.3em] uppercase mb-2"
              style={{ fontFamily: "Cinzel, serif" }}
            >
              {perfume.brand}
            </p>
            <h1 className="text-4xl font-bold text-foreground mb-3">{perfume.name}</h1>
            <div className="flex items-center gap-3 mb-2">
              <Stars rating={perfume.rating} size={14} />
              <span className="text-muted-foreground text-sm">
                {perfume.rating} ({perfume.reviews} تقييم)
              </span>
            </div>
            <p className="text-xs text-muted-foreground mb-6">
              المخزون المتاح:{" "}
              <span className={perfume.stock < 15 ? "text-red-400" : "text-emerald-400"}>
                {perfume.stock} قطعة
              </span>
            </p>

            <GoldDivider />

            <p className="text-muted-foreground leading-[1.9] my-6 text-sm">{perfume.description}</p>

            {/* Scent Notes */}
            <div className="grid grid-cols-3 gap-3 mb-8 p-5 bg-card border border-border">
              {(
                [
                  ["القمة", perfume.notes.top],
                  ["القلب", perfume.notes.heart],
                  ["القاعدة", perfume.notes.base],
                ] as [string, string[]][]
              ).map(([label, notes]) => (
                <div key={label}>
                  <p className="text-[10px] text-primary tracking-widest mb-2.5 uppercase">
                    {label}
                  </p>
                  {notes.map((n) => (
                    <p key={n} className="text-xs text-muted-foreground mb-1 leading-relaxed">
                      {n}
                    </p>
                  ))}
                </div>
              ))}
            </div>

            {/* Size Selector */}
            <div className="mb-6">
              <p className="text-xs text-muted-foreground tracking-widest uppercase mb-3">
                الحجم
              </p>
              <div className="flex gap-2">
                {perfume.sizes.map((s) => (
                  <button
                    key={s}
                    onClick={() => setSelectedSize(s)}
                    className={`flex-1 py-2.5 text-sm border transition-all duration-200 ${
                      selectedSize === s
                        ? "border-primary bg-primary/10 text-primary"
                        : "border-border text-muted-foreground hover:border-primary/35"
                    }`}
                  >
                    <span className="font-medium">{s}</span>
                    <span className="text-xs"> مل</span>
                    <p className="text-[10px] mt-0.5 opacity-70">
                      {perfumePrice(perfume, s)} ر.س
                    </p>
                  </button>
                ))}
              </div>
            </div>

            {/* Qty */}
            <div className="mb-8">
              <p className="text-xs text-muted-foreground tracking-widest uppercase mb-3">
                الكمية
              </p>
              <div className="flex items-center gap-4">
                <button
                  onClick={() => setQty(Math.max(1, qty - 1))}
                  className="w-9 h-9 border border-border flex items-center justify-center text-muted-foreground hover:border-primary/50 hover:text-primary transition-colors"
                >
                  <Minus size={13} />
                </button>
                <span className="text-foreground w-6 text-center font-medium">{qty}</span>
                <button
                  onClick={() => setQty(qty + 1)}
                  className="w-9 h-9 border border-border flex items-center justify-center text-muted-foreground hover:border-primary/50 hover:text-primary transition-colors"
                >
                  <Plus size={13} />
                </button>
              </div>
            </div>

            <GoldDivider />

            <div className="flex items-baseline gap-3 my-6">
              <span className="text-3xl font-bold text-primary">{totalPrice.toLocaleString()} ر.س</span>
              {qty > 1 && (
                <span className="text-sm text-muted-foreground">
                  ({perfumePrice(perfume, selectedSize)} × {qty})
                </span>
              )}
            </div>

            <button
              onClick={() => onAddToCart(perfume, selectedSize, qty)}
              className="w-full py-4 bg-primary text-primary-foreground font-medium text-sm tracking-widest hover:bg-primary/90 transition-colors"
            >
              إضافة إلى السلة
            </button>
          </div>
        </div>

        {/* Recommendations */}
        {recommended.length > 0 && (
          <div className="mt-24">
            <GoldDivider />
            <div className="flex items-center gap-3 my-8">
              <Sparkles size={15} className="text-primary" />
              <h2 className="text-base font-medium text-foreground">قد يعجبك أيضاً</h2>
              <span className="text-xs text-muted-foreground">
                — اقتراحات بناءً على التصنيف
              </span>
            </div>
            <div className="grid grid-cols-3 gap-6">
              {recommended.map((p) => (
                <div key={p.id} className="group cursor-pointer">
                  <div className="bg-card aspect-[3/4] overflow-hidden mb-3">
                    <img
                      src={img(p.image, 350, 460)}
                      alt={p.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                    />
                  </div>
                  <p className="text-[10px] text-muted-foreground uppercase tracking-widest mb-1">
                    {p.brand}
                  </p>
                  <p className="text-sm font-medium text-foreground mb-1">{p.name}</p>
                  <p className="text-primary text-sm">{p.price} ر.س</p>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// ─── Cart View ────────────────────────────────────────────────────────────────

function CartView({
  cart,
  onUpdate,
  onRemove,
  onCheckout,
  onContinue,
}: {
  cart: CartItem[];
  onUpdate: (id: number, size: number, qty: number) => void;
  onRemove: (id: number, size: number) => void;
  onCheckout: () => void;
  onContinue: () => void;
}) {
  const subtotal = cart.reduce(
    (acc, item) => acc + perfumePrice(item.perfume, item.size) * item.qty,
    0
  );
  const shipping = subtotal > 500 ? 0 : 25;

  if (cart.length === 0)
    return (
      <div className="pt-16 min-h-screen flex items-center justify-center">
        <div className="text-center">
          <ShoppingCart size={52} className="text-muted-foreground/20 mx-auto mb-5" />
          <p className="text-muted-foreground mb-6">سلة التسوق فارغة</p>
          <button
            onClick={onContinue}
            className="px-6 py-2.5 bg-primary text-primary-foreground text-sm hover:bg-primary/90 transition-colors"
          >
            تصفح المنتجات
          </button>
        </div>
      </div>
    );

  return (
    <div className="pt-16 min-h-screen">
      <div className="max-w-5xl mx-auto px-6 py-12">
        <h1 className="text-2xl font-bold text-foreground mb-10">
          سلة التسوق
          <span className="text-muted-foreground text-base font-normal mr-2">
            ({cart.length} منتج)
          </span>
        </h1>
        <div className="grid md:grid-cols-3 gap-8">
          <div className="md:col-span-2 space-y-3">
            {cart.map((item) => {
              const price = perfumePrice(item.perfume, item.size);
              return (
                <div
                  key={`${item.perfume.id}-${item.size}`}
                  className="flex gap-4 p-4 bg-card border border-border"
                >
                  <img
                    src={img(item.perfume.image, 160, 200)}
                    alt={item.perfume.name}
                    className="w-20 h-24 object-cover flex-shrink-0 bg-muted"
                  />
                  <div className="flex-1 min-w-0">
                    <div className="flex justify-between items-start mb-1">
                      <div>
                        <p className="text-[10px] text-muted-foreground uppercase tracking-widest">
                          {item.perfume.brand}
                        </p>
                        <p className="font-medium text-foreground">{item.perfume.name}</p>
                      </div>
                      <button
                        onClick={() => onRemove(item.perfume.id, item.size)}
                        className="text-muted-foreground hover:text-destructive transition-colors p-1"
                      >
                        <X size={14} />
                      </button>
                    </div>
                    <p className="text-xs text-muted-foreground mb-4">{item.size} مل</p>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <button
                          onClick={() =>
                            onUpdate(item.perfume.id, item.size, Math.max(1, item.qty - 1))
                          }
                          className="w-7 h-7 border border-border flex items-center justify-center text-muted-foreground hover:border-primary/50 hover:text-primary transition-colors"
                        >
                          <Minus size={11} />
                        </button>
                        <span className="text-sm text-foreground w-5 text-center">
                          {item.qty}
                        </span>
                        <button
                          onClick={() => onUpdate(item.perfume.id, item.size, item.qty + 1)}
                          className="w-7 h-7 border border-border flex items-center justify-center text-muted-foreground hover:border-primary/50 hover:text-primary transition-colors"
                        >
                          <Plus size={11} />
                        </button>
                      </div>
                      <span className="text-primary font-semibold">
                        {(price * item.qty).toLocaleString()} ر.س
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Order Summary */}
          <div className="bg-card border border-border p-6 h-fit">
            <h2 className="font-medium text-foreground mb-4 text-sm tracking-wide">
              ملخص الطلب
            </h2>
            <GoldDivider />
            <div className="space-y-3 mt-5 text-sm">
              <div className="flex justify-between text-muted-foreground">
                <span>المجموع الفرعي</span>
                <span>{subtotal.toLocaleString()} ر.س</span>
              </div>
              <div className="flex justify-between text-muted-foreground">
                <span>الشحن</span>
                <span>{shipping === 0 ? "مجاني" : `${shipping} ر.س`}</span>
              </div>
              {shipping === 0 && (
                <p className="text-[11px] text-primary/80 border border-primary/20 bg-primary/5 px-2 py-1.5">
                  ✦ شحن مجاني للطلبات فوق ٥٠٠ ر.س
                </p>
              )}
            </div>
            <GoldDivider />
            <div className="flex justify-between font-semibold text-foreground mt-5 mb-7">
              <span>الإجمالي</span>
              <span className="text-primary text-xl">
                {(subtotal + shipping).toLocaleString()} ر.س
              </span>
            </div>
            <button
              onClick={onCheckout}
              className="w-full py-3.5 bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors tracking-wide"
            >
              إتمام الطلب
            </button>
            <button
              onClick={onContinue}
              className="w-full py-2.5 mt-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
            >
              مواصلة التسوق
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Checkout View ────────────────────────────────────────────────────────────

function CheckoutView({
  onConfirm,
  onBack,
}: {
  onConfirm: () => void;
  onBack: () => void;
}) {
  const [form, setForm] = useState({
    name: "",
    phone: "",
    email: "",
    city: "",
    address: "",
  });
  const [placed, setPlaced] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setPlaced(true);
    setTimeout(onConfirm, 2500);
  };

  if (placed)
    return (
      <div className="pt-16 min-h-screen flex items-center justify-center">
        <div className="text-center max-w-sm">
          <div className="w-16 h-16 border border-primary/50 flex items-center justify-center mx-auto mb-6 bg-primary/5">
            <CheckCircle size={28} className="text-primary" />
          </div>
          <p
            className="text-primary text-xs tracking-widest uppercase mb-3"
            style={{ fontFamily: "Cinzel, serif" }}
          >
            Order Confirmed
          </p>
          <h2 className="text-xl font-bold text-foreground mb-3">تم تأكيد طلبك بنجاح!</h2>
          <p className="text-muted-foreground text-sm leading-relaxed">
            سيتم التواصل معك قريباً لتأكيد التفاصيل وموعد التسليم
          </p>
        </div>
      </div>
    );

  const fields = [
    { key: "name", label: "الاسم الكامل", type: "text", col: 1 },
    { key: "phone", label: "رقم الهاتف", type: "tel", col: 1 },
    { key: "email", label: "البريد الإلكتروني", type: "email", col: 2 },
    { key: "city", label: "المدينة", type: "text", col: 1 },
    { key: "address", label: "العنوان التفصيلي", type: "text", col: 1 },
  ];

  return (
    <div className="pt-16 min-h-screen">
      <div className="max-w-xl mx-auto px-6 py-12">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-sm text-muted-foreground hover:text-primary transition-colors mb-8"
        >
          <ChevronRight size={16} />
          العودة للسلة
        </button>

        <p
          className="text-primary text-[11px] tracking-[0.3em] uppercase mb-2"
          style={{ fontFamily: "Cinzel, serif" }}
        >
          Checkout
        </p>
        <h1 className="text-2xl font-bold text-foreground mb-8">إتمام الطلب</h1>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            {fields
              .filter((f) => f.col === 1)
              .map(({ key, label, type }) => (
                <div key={key}>
                  <label className="block text-[11px] text-muted-foreground tracking-wider uppercase mb-1.5">
                    {label}
                  </label>
                  <input
                    required
                    type={type}
                    value={(form as Record<string, string>)[key]}
                    onChange={(e) => setForm({ ...form, [key]: e.target.value })}
                    className="w-full px-3 py-2.5 bg-card border border-border text-foreground text-sm focus:outline-none focus:border-primary/50 placeholder:text-muted-foreground/30"
                  />
                </div>
              ))}
          </div>
          {fields
            .filter((f) => f.col === 2)
            .map(({ key, label, type }) => (
              <div key={key}>
                <label className="block text-[11px] text-muted-foreground tracking-wider uppercase mb-1.5">
                  {label}
                </label>
                <input
                  required
                  type={type}
                  value={(form as Record<string, string>)[key]}
                  onChange={(e) => setForm({ ...form, [key]: e.target.value })}
                  className="w-full px-3 py-2.5 bg-card border border-border text-foreground text-sm focus:outline-none focus:border-primary/50"
                />
              </div>
            ))}

          {/* Payment */}
          <div className="mt-2">
            <label className="block text-[11px] text-muted-foreground tracking-wider uppercase mb-3">
              طريقة الدفع
            </label>
            <div className="p-4 bg-card border border-primary/30 flex items-center gap-3">
              <div className="w-4 h-4 rounded-full border-2 border-primary flex items-center justify-center flex-shrink-0">
                <div className="w-2 h-2 rounded-full bg-primary" />
              </div>
              <div>
                <p className="text-sm text-foreground">الدفع عند الاستلام</p>
                <p className="text-xs text-muted-foreground">Cash on Delivery</p>
              </div>
            </div>
            <div className="p-4 bg-card border border-border flex items-center gap-3 mt-2 opacity-50">
              <div className="w-4 h-4 rounded-full border-2 border-border flex-shrink-0" />
              <div>
                <p className="text-sm text-foreground">بطاقة ائتمانية</p>
                <p className="text-xs text-muted-foreground">قريباً</p>
              </div>
            </div>
          </div>

          <button
            type="submit"
            className="w-full py-4 bg-primary text-primary-foreground font-medium text-sm tracking-widest hover:bg-primary/90 transition-colors mt-4"
          >
            تأكيد الطلب
          </button>
        </form>
      </div>
    </div>
  );
}

// ─── Admin Overview ───────────────────────────────────────────────────────────

function AdminOverview() {
  const stats = [
    { label: "إجمالي المبيعات", value: "٩٥,٠٠٠ ر.س", icon: TrendingUp, delta: "+٢٣٪" },
    { label: "الطلبات هذا الشهر", value: "١٥٢", icon: ShoppingBag, delta: "+١٨٪" },
    { label: "المنتجات النشطة", value: "٨", icon: Package, delta: "" },
    { label: "العملاء الجدد", value: "٤٧", icon: Users, delta: "+٣١٪" },
  ];

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-xl font-bold text-foreground mb-1">نظرة عامة</h1>
        <p className="text-sm text-muted-foreground">يناير ٢٠٢٤ — آخر تحديث منذ قليل</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {stats.map((s) => (
          <div key={s.label} className="bg-card border border-border p-5 relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-primary/40 via-primary/20 to-transparent" />
            <div className="flex items-start justify-between mb-4">
              <s.icon size={15} className="text-primary mt-0.5" />
              {s.delta && (
                <span className="text-[11px] text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-1.5 py-0.5">
                  {s.delta}
                </span>
              )}
            </div>
            <p className="text-2xl font-bold text-foreground mb-1">{s.value}</p>
            <p className="text-xs text-muted-foreground">{s.label}</p>
          </div>
        ))}
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-2 gap-5 mb-5">
        <div className="bg-card border border-border p-5">
          <h3 className="text-sm font-medium text-foreground mb-0.5">المبيعات الشهرية</h3>
          <p className="text-xs text-muted-foreground mb-5">آخر ٧ أشهر (ر.س)</p>
          <ResponsiveContainer width="100%" height={200}>
            <AreaChart data={SALES_DATA} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="goldGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#c49838" stopOpacity={0.25} />
                  <stop offset="95%" stopColor="#c49838" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.03)" />
              <XAxis
                dataKey="month"
                tick={{ fill: "#7a6a4a", fontSize: 10 }}
                axisLine={false}
                tickLine={false}
              />
              <YAxis
                tick={{ fill: "#7a6a4a", fontSize: 10 }}
                axisLine={false}
                tickLine={false}
                tickFormatter={(v) => `${v / 1000}k`}
              />
              <Tooltip
                contentStyle={{
                  background: "#110e09",
                  border: "1px solid rgba(196,152,56,0.2)",
                  borderRadius: 0,
                  fontSize: 12,
                }}
                labelStyle={{ color: "#ede5d4" }}
                itemStyle={{ color: "#c49838" }}
              />
              <Area
                type="monotone"
                dataKey="sales"
                stroke="#c49838"
                strokeWidth={1.5}
                fill="url(#goldGrad)"
                dot={false}
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-card border border-border p-5">
          <h3 className="text-sm font-medium text-foreground mb-0.5">عدد الطلبات</h3>
          <p className="text-xs text-muted-foreground mb-5">آخر ٧ أشهر</p>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart
              data={SALES_DATA}
              barSize={20}
              margin={{ top: 0, right: 0, left: -20, bottom: 0 }}
            >
              <CartesianGrid
                strokeDasharray="3 3"
                stroke="rgba(255,255,255,0.03)"
                vertical={false}
              />
              <XAxis
                dataKey="month"
                tick={{ fill: "#7a6a4a", fontSize: 10 }}
                axisLine={false}
                tickLine={false}
              />
              <YAxis
                tick={{ fill: "#7a6a4a", fontSize: 10 }}
                axisLine={false}
                tickLine={false}
              />
              <Tooltip
                contentStyle={{
                  background: "#110e09",
                  border: "1px solid rgba(196,152,56,0.2)",
                  borderRadius: 0,
                  fontSize: 12,
                }}
                labelStyle={{ color: "#ede5d4" }}
                itemStyle={{ color: "#c49838" }}
              />
              <Bar dataKey="orders" fill="#c49838" fillOpacity={0.65} radius={[1, 1, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* ML Predictions */}
      <div className="bg-card border border-border p-5">
        <div className="flex items-start gap-3 mb-6">
          <div className="w-8 h-8 border border-primary/30 bg-primary/5 flex items-center justify-center flex-shrink-0 mt-0.5">
            <Bot size={14} className="text-primary" />
          </div>
          <div>
            <h3 className="text-sm font-medium text-foreground">توقعات نموذج التعلم الآلي</h3>
            <p className="text-xs text-muted-foreground">
              تنبؤ بالأرباح المتوقعة للشهر القادم — بناءً على بيانات المبيعات السابقة
            </p>
          </div>
          <span className="text-[10px] text-primary bg-primary/10 border border-primary/20 px-2 py-0.5 mr-auto">
            ML Active
          </span>
        </div>
        <div className="space-y-5">
          {ML_PREDICTIONS.map((p) => (
            <div key={p.category} className="flex items-center gap-4">
              <span className="text-sm text-muted-foreground w-14 text-right flex-shrink-0">
                {p.category}
              </span>
              <div className="flex-1 h-1.5 bg-muted rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-l from-primary to-primary/50 transition-all duration-1000"
                  style={{ width: `${(p.predicted / 62000) * 100}%` }}
                />
              </div>
              <span className="text-xs text-foreground w-28 text-left flex-shrink-0">
                {p.predicted.toLocaleString()} ر.س
              </span>
              <span className="text-[11px] text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 w-14 text-center flex-shrink-0">
                +{p.growth}٪
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── Admin Products ───────────────────────────────────────────────────────────

function AdminProducts() {
  return (
    <div>
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-xl font-bold text-foreground mb-1">إدارة المنتجات</h1>
          <p className="text-sm text-muted-foreground">{PERFUMES.length} عطر مسجل في المتجر</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2.5 bg-primary text-primary-foreground text-sm hover:bg-primary/90 transition-colors">
          <Plus size={14} />
          إضافة عطر جديد
        </button>
      </div>

      <div className="bg-card border border-border overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-border">
              {["الصورة", "العطر", "التصنيف", "السعر", "المخزون", "التقييم", ""].map(
                (h, i) => (
                  <th
                    key={i}
                    className="text-right text-[11px] text-muted-foreground font-medium px-4 py-3 tracking-wider uppercase"
                  >
                    {h}
                  </th>
                )
              )}
            </tr>
          </thead>
          <tbody>
            {PERFUMES.map((p, i) => (
              <tr
                key={p.id}
                className={`hover:bg-muted/20 transition-colors ${
                  i < PERFUMES.length - 1 ? "border-b border-border/50" : ""
                }`}
              >
                <td className="px-4 py-3">
                  <img
                    src={img(p.image, 80, 100)}
                    alt={p.name}
                    className="w-10 h-12 object-cover bg-muted"
                  />
                </td>
                <td className="px-4 py-3">
                  <p className="text-foreground font-medium">{p.name}</p>
                  <p className="text-xs text-muted-foreground">{p.brand}</p>
                </td>
                <td className="px-4 py-3">
                  <span className="text-xs px-2 py-0.5 bg-primary/8 text-primary border border-primary/20">
                    {p.category}
                  </span>
                </td>
                <td className="px-4 py-3 text-foreground">{p.price} ر.س</td>
                <td className="px-4 py-3">
                  <span
                    className={`text-xs font-medium ${
                      p.stock < 15 ? "text-red-400" : "text-emerald-400"
                    }`}
                  >
                    {p.stock}
                  </span>
                </td>
                <td className="px-4 py-3">
                  <div className="flex items-center gap-1">
                    <Star size={11} className="fill-primary text-primary" />
                    <span className="text-xs text-foreground">{p.rating}</span>
                    <span className="text-[10px] text-muted-foreground">({p.reviews})</span>
                  </div>
                </td>
                <td className="px-4 py-3">
                  <div className="flex items-center gap-1">
                    <button className="p-1.5 text-muted-foreground hover:text-primary transition-colors">
                      <Eye size={13} />
                    </button>
                    <button className="p-1.5 text-muted-foreground hover:text-primary transition-colors">
                      <Pencil size={13} />
                    </button>
                    <button className="p-1.5 text-muted-foreground hover:text-destructive transition-colors">
                      <Trash2 size={13} />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ─── Admin Orders ─────────────────────────────────────────────────────────────

function AdminOrders() {
  const [filter, setFilter] = useState<OrderStatus | "الكل">("الكل");

  const filtered =
    filter === "الكل" ? ORDERS : ORDERS.filter((o) => o.status === filter);

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-xl font-bold text-foreground mb-1">الطلبات</h1>
          <p className="text-sm text-muted-foreground">{ORDERS.length} طلب إجمالاً</p>
        </div>
      </div>

      <div className="flex gap-2 mb-6">
        {(["الكل", "جديد", "قيد التجهيز", "مكتمل", "ملغي"] as const).map((s) => (
          <button
            key={s}
            onClick={() => setFilter(s)}
            className={`px-3 py-1.5 text-xs border transition-all ${
              filter === s
                ? "border-primary bg-primary/10 text-primary"
                : "border-border text-muted-foreground hover:border-primary/35"
            }`}
          >
            {s}
          </button>
        ))}
      </div>

      <div className="bg-card border border-border overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-border">
              {["رقم الطلب", "العميل", "التاريخ", "المنتجات", "الإجمالي", "الحالة", ""].map(
                (h, i) => (
                  <th
                    key={i}
                    className="text-right text-[11px] text-muted-foreground font-medium px-4 py-3 tracking-wider uppercase"
                  >
                    {h}
                  </th>
                )
              )}
            </tr>
          </thead>
          <tbody>
            {filtered.map((o, i) => (
              <tr
                key={o.id}
                className={`hover:bg-muted/20 transition-colors ${
                  i < filtered.length - 1 ? "border-b border-border/50" : ""
                }`}
              >
                <td className="px-4 py-3 font-mono text-[11px] text-primary">{o.id}</td>
                <td className="px-4 py-3 text-foreground">{o.customer}</td>
                <td className="px-4 py-3 text-muted-foreground text-xs">{o.date}</td>
                <td className="px-4 py-3 text-muted-foreground text-xs">{o.items} منتج</td>
                <td className="px-4 py-3 text-foreground font-medium">
                  {o.total.toLocaleString()} ر.س
                </td>
                <td className="px-4 py-3">
                  <StatusBadge status={o.status} />
                </td>
                <td className="px-4 py-3">
                  <div className="flex items-center gap-1">
                    <button className="p-1.5 text-muted-foreground hover:text-primary transition-colors">
                      <Eye size={13} />
                    </button>
                    <button className="p-1.5 text-muted-foreground hover:text-primary transition-colors">
                      <Pencil size={13} />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ─── Admin View ───────────────────────────────────────────────────────────────

function AdminView({ onBack, onLogout }: { onBack: () => void; onLogout: () => void }) {
  const [tab, setTab] = useState<AdminTab>("overview");

  const tabs = [
    { id: "overview" as AdminTab, label: "نظرة عامة", icon: BarChart2 },
    { id: "products" as AdminTab, label: "المنتجات", icon: Package },
    { id: "orders" as AdminTab, label: "الطلبات", icon: ShoppingBag },
  ];

  return (
    <div className="min-h-screen flex">
      {/* Sidebar */}
      <aside className="fixed right-0 top-0 h-screen w-56 bg-card border-l border-border flex flex-col">
        <div className="p-5 border-b border-border">
          <p
            className="text-primary text-lg tracking-widest"
            style={{ fontFamily: "Cinzel, serif" }}
          >
            ÛTOOR
          </p>
          <p className="text-[10px] text-muted-foreground tracking-widest uppercase mt-0.5">
            Admin Panel
          </p>
        </div>
        <nav className="flex-1 p-3 space-y-1">
          {tabs.map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              onClick={() => setTab(id)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 text-sm transition-all ${
                tab === id
                  ? "bg-primary/10 text-primary border border-primary/20"
                  : "text-muted-foreground hover:text-foreground hover:bg-muted/40"
              }`}
            >
              <Icon size={14} />
              {label}
            </button>
          ))}
        </nav>
        <div className="p-3 border-t border-border space-y-1">
          <button
            onClick={onBack}
            className="w-full flex items-center gap-3 px-3 py-2.5 text-sm text-muted-foreground hover:text-foreground transition-colors"
          >
            <ArrowRight size={14} />
            العودة للمتجر
          </button>
          <button
            onClick={onLogout}
            className="w-full flex items-center gap-3 px-3 py-2.5 text-sm text-destructive/70 hover:text-destructive transition-colors"
          >
            <LogIn size={14} className="rotate-180" />
            تسجيل الخروج
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="mr-56 flex-1 p-8 overflow-auto">
        {tab === "overview" && <AdminOverview />}
        {tab === "products" && <AdminProducts />}
        {tab === "orders" && <AdminOrders />}
      </main>
    </div>
  );
}

// ─── App ──────────────────────────────────────────────────────────────────────

export default function App() {
  const [view, setView] = useState<View>("home");
  const [selectedProduct, setSelectedProduct] = useState<Perfume | null>(null);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isAdmin, setIsAdmin] = useState(false);
  const [showLogin, setShowLogin] = useState(false);

  const addToCart = (perfume: Perfume, size: number, qty = 1) => {
    setCart((prev) => {
      const existing = prev.find(
        (i) => i.perfume.id === perfume.id && i.size === size
      );
      if (existing)
        return prev.map((i) =>
          i.perfume.id === perfume.id && i.size === size
            ? { ...i, qty: i.qty + qty }
            : i
        );
      return [...prev, { perfume, size, qty }];
    });
  };

  const updateCart = (id: number, size: number, qty: number) => {
    setCart((prev) =>
      prev.map((i) => (i.perfume.id === id && i.size === size ? { ...i, qty } : i))
    );
  };

  const removeFromCart = (id: number, size: number) => {
    setCart((prev) => prev.filter((i) => !(i.perfume.id === id && i.size === size)));
  };

  const cartCount = cart.reduce((acc, i) => acc + i.qty, 0);

  const navigate = (v: View) => {
    if (v === "home") setSelectedProduct(null);
    setView(v);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <div
      className="min-h-screen bg-background text-foreground"
      dir="rtl"
      style={{ fontFamily: "Tajawal, sans-serif" }}
    >
      {showLogin && (
        <AdminLogin
          onSuccess={() => { setIsAdmin(true); setShowLogin(false); navigate("admin"); }}
          onCancel={() => setShowLogin(false)}
        />
      )}

      {view !== "admin" && (
        <Navbar
          view={view}
          onNav={navigate}
          cartCount={cartCount}
          isAdmin={isAdmin}
          onAdminClick={() => setShowLogin(true)}
          onAdminLogout={() => { setIsAdmin(false); navigate("home"); }}
        />
      )}

      {view === "home" && (
        <HomeView
          onSelectProduct={(p) => {
            setSelectedProduct(p);
            navigate("product");
          }}
          onAddToCart={(p, s) => {
            addToCart(p, s);
            navigate("cart");
          }}
        />
      )}

      {view === "product" && selectedProduct && (
        <ProductView
          perfume={selectedProduct}
          onBack={() => navigate("home")}
          onAddToCart={(p, s, q) => {
            addToCart(p, s, q);
            navigate("cart");
          }}
        />
      )}

      {view === "cart" && (
        <CartView
          cart={cart}
          onUpdate={updateCart}
          onRemove={removeFromCart}
          onCheckout={() => navigate("checkout")}
          onContinue={() => navigate("home")}
        />
      )}

      {view === "checkout" && (
        <CheckoutView
          onConfirm={() => {
            setCart([]);
            navigate("home");
          }}
          onBack={() => navigate("cart")}
        />
      )}

      {view === "admin" && (
        <AdminView
          onBack={() => navigate("home")}
          onLogout={() => { setIsAdmin(false); navigate("home"); }}
        />
      )}
    </div>
  );
}
